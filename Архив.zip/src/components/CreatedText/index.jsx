import "./index.css"

const CreatedText = () =>{
    return (
        <span onClick={() => window.location.href="https://t.me/beautywebapp_bot"} className="created_text">Разработано в <u>Beautywebapp</u></span>
    )
}

export default CreatedText;